#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class CmdVelPublisher(Node):

    def __init__(self):
        super().__init__('cmd_vel_publisher')
        # Create a publisher that publishes to the /cmd_vel topic
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # Timer to control the publishing frequency (2 Hz)
        self.timer = self.create_timer(0.5, self.timer_callback)

    def timer_callback(self):
        # Create a new Twist message
        msg = Twist()

        # Set the linear velocity (x) and angular velocity (z)
        msg.linear.x = 0.0   # Move forward with 0.5 m/s
        msg.angular.z = 0.2  # Rotate counter-clockwise with 0.2 rad/s

        # Publish the message
        self.publisher_.publish(msg)

        self.get_logger().info('Publishing: linear.x: %.2f, angular.z: %.2f' % (msg.linear.x, msg.angular.z))

def main(args=None):
    rclpy.init(args=args)
    node = CmdVelPublisher()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    # Shutdown the node when done
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
