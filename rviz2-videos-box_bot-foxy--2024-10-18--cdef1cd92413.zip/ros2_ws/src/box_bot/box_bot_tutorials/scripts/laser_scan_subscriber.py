#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
import matplotlib.pyplot as plt
import numpy as np

class LaserScanSubscriber(Node):

    def __init__(self):
        super().__init__('laser_scan_subscriber')
        # Subscribe to the LaserScan topic
        self.subscription = self.create_subscription(
            LaserScan,
            '/box_bot/laser_scan',
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning

        # Set up live plot
        plt.ion()
        self.fig, self.ax = plt.subplots()
        self.ln, = plt.plot([], [], 'ro')  # Initialize plot as red dots

        self.get_logger().info("Laser scan subscriber initialised")

    def listener_callback(self, msg):
        self.get_logger().info("Received scan from topic")

        # Convert polar coordinates (range, angle) to Cartesian (x, y)
        angles = np.arange(msg.angle_min, msg.angle_max, msg.angle_increment)
        ranges = np.array(msg.ranges)

        # Filter out invalid ranges (0 or inf)
        valid_indices = np.isfinite(ranges) & (ranges > 0)
        ranges = ranges[valid_indices]
        angles = angles[valid_indices]

        x = ranges * np.cos(angles)
        y = ranges * np.sin(angles)

        # Update the plot with new data
        self.ln.set_xdata(x)
        self.ln.set_ydata(y)
        self.ax.set_xlim([-max(ranges), max(ranges)])
        self.ax.set_ylim([-max(ranges), max(ranges)])
        self.fig.canvas.draw()
        self.fig.canvas.flush_events()

def main(args=None):
    rclpy.init(args=args)
    laser_scan_subscriber = LaserScanSubscriber()
    rclpy.spin(laser_scan_subscriber)
    laser_scan_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
