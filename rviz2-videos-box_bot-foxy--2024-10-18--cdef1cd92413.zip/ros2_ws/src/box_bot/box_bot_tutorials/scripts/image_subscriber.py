#! /usr/bin/env python


import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

class ImageSubscriber(Node):

    def __init__(self):
        super().__init__('image_subscriber')
        # Subscribe to the image topic
        self.subscription = self.create_subscription(
            Image,
            '/rgb_camera_ns/rgb_camera_camera/image_raw',
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning
        self.bridge = CvBridge()

        self.get_logger().info("Image subscriber initialised")

    def listener_callback(self, msg):
        # Convert the ROS Image message to a format OpenCV can use

        
        self.get_logger().info("Received image from topic")

        #cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")


        # Display the image using OpenCV
        #cv2.imshow("Camera Image", cv_image)
        #cv2.waitKey(1)  # Adds delay for image to render properly



def main(args=None):
    rclpy.init(args=args)
    image_subscriber = ImageSubscriber()
    rclpy.spin(image_subscriber)

    
    image_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
