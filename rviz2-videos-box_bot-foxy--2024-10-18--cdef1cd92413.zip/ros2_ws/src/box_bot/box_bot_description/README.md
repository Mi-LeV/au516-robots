Mesh extracted from : https://skfb.ly/6XzGu


